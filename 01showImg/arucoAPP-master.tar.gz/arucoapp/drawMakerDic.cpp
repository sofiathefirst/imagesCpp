#include <iostream>
#include<opencv2/opencv.hpp>
#include<opencv2/aruco.hpp>
using namespace std;
using namespace cv;

int main(int argc, char **argv)
{

	cv::Ptr<cv::aruco::Dictionary> dictionary = cv::aruco::getPredefinedDictionary(7);

	cv::Mat   imageCopy;


	char name[10];

	for(int i=0;i<1000;i++)
	{
		cv::aruco::drawMarker(dictionary,i,atoi( argv[1]), imageCopy, 1); 
		imshow("mak34er", imageCopy);

		sprintf(name , "maker%d_%d.jpg", i,atoi( argv[1]));
		imwrite(name, imageCopy);
	}
	char key = (char) cv::waitKey(4000);

	return 0;
}
